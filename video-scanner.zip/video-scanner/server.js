const express = require("express");
const cors = require("cors");
const axios = require("axios");
const cheerio = require("cheerio");
const dns = require("dns").promises;
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const VIDEO_EXT_REGEX = /\.(mp4|webm|mov|m4v|ogv|ogg|m3u8|mpd)(\?[^\s"'<>]*)?$/i;
const VIDEO_URL_REGEX =
  /https?:\/\/[^\s"'<>\\]+\.(mp4|webm|mov|m4v|ogv|m3u8|mpd)(\?[^\s"'<>\\]*)?/gi;

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

// ---------- Basic SSRF guard ----------
// Blockiert Anfragen an private/lokale Adressen, damit das Tool nicht als
// Scanner für interne Netzwerke / localhost missbraucht werden kann.
function isPrivateIp(ip) {
  if (!ip) return true;
  const v4 = ip.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
  const addr = v4 ? v4[1] : ip;

  if (addr === "::1" || addr === "127.0.0.1") return true;
  if (/^0\./.test(addr)) return true;
  if (/^10\./.test(addr)) return true;
  if (/^127\./.test(addr)) return true;
  if (/^169\.254\./.test(addr)) return true;
  if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(addr)) return true;
  if (/^192\.168\./.test(addr)) return true;
  if (/^fc00:|^fd00:|^fe80:/.test(addr)) return true;
  return false;
}

async function assertPublicUrl(rawUrl) {
  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    throw new Error("Ungültige URL.");
  }
  if (!["http:", "https:"].includes(parsed.protocol)) {
    throw new Error("Nur http/https-URLs sind erlaubt.");
  }
  const hostname = parsed.hostname;
  if (hostname === "localhost") throw new Error("Lokale Adressen sind nicht erlaubt.");

  let addresses;
  try {
    addresses = await dns.lookup(hostname, { all: true });
  } catch {
    throw new Error("Hostname konnte nicht aufgelöst werden.");
  }
  if (addresses.some((a) => isPrivateIp(a.address))) {
    throw new Error("Private/lokale Adressen sind nicht erlaubt.");
  }
  return parsed;
}

function resolveUrl(link, base) {
  try {
    return new URL(link, base).href;
  } catch {
    return null;
  }
}

function guessType(url) {
  const m = url.match(VIDEO_EXT_REGEX);
  if (!m) return "unknown";
  const ext = m[1].toLowerCase();
  if (ext === "m3u8") return "hls";
  if (ext === "mpd") return "dash";
  return ext;
}

function extractVideosFromHtml(html, baseUrl) {
  const $ = cheerio.load(html);
  const found = new Map();

  const add = (link, label) => {
    const abs = resolveUrl(link, baseUrl);
    if (!abs) return;
    if (!found.has(abs)) {
      found.set(abs, { url: abs, type: guessType(abs), label });
    }
  };

  $("video").each((_, el) => {
    const src = $(el).attr("src");
    if (src) add(src, "video-tag");
    $(el)
      .find("source")
      .each((__, s) => {
        const ssrc = $(s).attr("src");
        if (ssrc) add(ssrc, "video-source");
      });
  });

  $("source").each((_, el) => {
    const src = $(el).attr("src");
    const type = $(el).attr("type") || "";
    if (src && (VIDEO_EXT_REGEX.test(src) || type.startsWith("video/"))) {
      add(src, "source-tag");
    }
  });

  const metaSelectors = [
    'meta[property="og:video"]',
    'meta[property="og:video:url"]',
    'meta[property="og:video:secure_url"]',
    'meta[name="twitter:player:stream"]',
  ];
  metaSelectors.forEach((sel) => {
    $(sel).each((_, el) => {
      const content = $(el).attr("content");
      if (content) add(content, "meta-tag");
    });
  });

  $("a").each((_, el) => {
    const href = $(el).attr("href");
    if (href && VIDEO_EXT_REGEX.test(href)) add(href, "link");
  });

  // Fallback: rohe Video-URLs irgendwo im HTML/Inline-JS aufspüren
  const matches = html.match(VIDEO_URL_REGEX) || [];
  matches.forEach((m) => add(m, "raw-match"));

  return Array.from(found.values());
}

// ---------- API: Seite scannen ----------
app.post("/api/scan", async (req, res) => {
  const { url } = req.body || {};
  if (!url) return res.status(400).json({ error: "Feld 'url' fehlt." });

  try {
    const parsed = await assertPublicUrl(url);

    // Fall 1: Der Link ist bereits eine direkte Videodatei
    if (VIDEO_EXT_REGEX.test(parsed.pathname)) {
      return res.json({
        sourceUrl: url,
        videos: [{ url, type: guessType(url), label: "direct-link" }],
      });
    }

    const response = await axios.get(url, {
      headers: { "User-Agent": UA },
      timeout: 15000,
      maxContentLength: 15 * 1024 * 1024, // 15 MB HTML-Limit
      responseType: "text",
      validateStatus: (s) => s < 400,
    });

    const contentType = response.headers["content-type"] || "";
    if (contentType.startsWith("video/")) {
      return res.json({
        sourceUrl: url,
        videos: [{ url, type: guessType(url) || "video", label: "direct-link" }],
      });
    }

    const videos = extractVideosFromHtml(response.data, url);
    res.json({ sourceUrl: url, videos });
  } catch (err) {
    res.status(400).json({ error: err.message || "Scan fehlgeschlagen." });
  }
});

// ---------- API: Video herunterladen (Proxy-Stream) ----------
app.get("/api/download", async (req, res) => {
  const { url, filename } = req.query;
  if (!url) return res.status(400).send("Feld 'url' fehlt.");

  try {
    await assertPublicUrl(url);

    const upstream = await axios.get(url, {
      headers: { "User-Agent": UA, Referer: url },
      responseType: "stream",
      timeout: 20000,
      maxRedirects: 5,
      validateStatus: (s) => s < 400,
    });

    const safeName =
      (filename && filename.replace(/[^\w.\-]+/g, "_")) ||
      path.basename(new URL(url).pathname) ||
      "video";

    res.setHeader("Content-Disposition", `attachment; filename="${safeName}"`);
    if (upstream.headers["content-type"]) {
      res.setHeader("Content-Type", upstream.headers["content-type"]);
    }
    if (upstream.headers["content-length"]) {
      res.setHeader("Content-Length", upstream.headers["content-length"]);
    }

    upstream.data.pipe(res);
    upstream.data.on("error", () => res.end());
  } catch (err) {
    res.status(400).send(err.message || "Download fehlgeschlagen.");
  }
});

app.listen(PORT, () => {
  console.log(`Video-Scanner läuft auf http://localhost:${PORT}`);
});
