# Signal — Video-Scanner

Ein kleines Tool, das eine beliebige Webseite nach eingebetteten Videos durchsucht
(`<video>`-Tags, `og:video`-Metadaten, direkte `.mp4`/`.webm`/`.m3u8`-Links) und
gefundene Treffer zum Download anbietet.

## Architektur

- **Backend** (`server.js`): Node.js + Express. Ruft die Zielseite serverseitig ab
  (umgeht CORS), sucht nach Videoquellen und streamt Downloads als Proxy durch.
- **Frontend** (`public/index.html`): Einfache Oberfläche, keine Frameworks nötig.

Ein statisches Hosting wie **GitHub Pages reicht nicht aus** — der Scan- und
Download-Endpunkt braucht einen laufenden Server. Das Repo kannst du trotzdem auf
GitHub verwalten; den Server deployst du zusätzlich z. B. auf Render, Railway,
Fly.io oder einem eigenen VPS.

## Lokal starten

```bash
npm install
npm start
```

Danach ist die Oberfläche unter `http://localhost:3000` erreichbar.

## Auf GitHub veröffentlichen

```bash
git init
git add .
git commit -m "Initial commit: Video-Scanner"
git branch -M main
git remote add origin https://github.com/<dein-user>/<dein-repo>.git
git push -u origin main
```

## Deployment (z. B. Render.com, kostenlose Stufe verfügbar)

1. Repo mit Render verbinden ("New → Web Service").
2. Build Command: `npm install`
3. Start Command: `npm start`
4. Node-Version ≥ 18 sicherstellen.

Alternativ funktioniert das genauso auf Railway, Fly.io oder Heroku-ähnlichen
Plattformen — überall dort, wo ein Node.js-Prozess dauerhaft laufen kann.

## Wie die Erkennung funktioniert

1. Ist die eingegebene URL selbst schon eine Videodatei → direkter Treffer.
2. Andernfalls wird das HTML der Seite geladen und durchsucht nach:
   - `<video src>` und verschachtelten `<source>`-Tags
   - `og:video`, `og:video:url`, `twitter:player:stream`-Metadaten
   - Links, die auf `.mp4`, `.webm`, `.mov`, `.m3u8`, `.mpd` usw. enden
   - rohen Video-URLs, die irgendwo im HTML/Inline-JS auftauchen

**HLS-Streams (`.m3u8`) und DASH (`.mpd`)** sind Playlists, keine einzelnen
Dateien. Sie werden erkannt, aber nicht automatisch zu einer mp4 zusammengeführt —
dafür bräuchte es zusätzlich `ffmpeg` (z. B. `ffmpeg -i playlist.m3u8 -c copy out.mp4`).

## Eingebaute Sicherheitsvorkehrung

Der Server blockiert Anfragen an private/lokale Adressen (`localhost`, `127.0.0.1`,
`10.x`, `192.168.x`, `169.254.x` usw.), damit das Tool nicht zum Abscannen interner
Netzwerke missbraucht werden kann (SSRF-Schutz). Für einen produktiven Einsatz
solltest du zusätzlich Rate-Limiting einbauen (z. B. mit `express-rate-limit`).

## Rechtlicher Hinweis

Lade nur Videos herunter, für die du die Rechte hast oder deren Lizenz/Nutzungs-
bedingungen das ausdrücklich erlauben (z. B. eigene Inhalte oder Creative-Commons-
Material). Das automatisierte Herunterladen von Inhalten großer Plattformen
(YouTube, Instagram, TikTok etc.) verstößt in der Regel gegen deren Nutzungs-
bedingungen und kann Urheberrechte verletzen — dieses Tool ist bewusst nur für
offen eingebettete Videodateien/Streams gedacht, nicht als Umgehung dieser
Plattformen konzipiert.
